plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.ftranslator"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.ftranslator"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "0.1.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
}
