package com.example.ftranslator

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors

/**
 * Demo online translation adapter. MyMemory is a third-party service with
 * usage limits and no uptime guarantee. Replace this endpoint with your own
 * LibreTranslate/translation provider for production use.
 */
object Translator {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun translate(text: String, callback: (Result<String>) -> Unit) {
        if (text.isBlank()) {
            callback(Result.failure(IllegalArgumentException("请先输入或识别文字")))
            return
        }
        executor.execute {
            try {
                val q = URLEncoder.encode(text.take(450), "UTF-8")
                val url = URL("https://api.mymemory.translated.net/get?q=$q&langpair=autodetect|zh-CN")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12000
                    readTimeout = 15000
                    setRequestProperty("Accept", "application/json")
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val translated = JSONObject(body)
                    .getJSONObject("responseData")
                    .optString("translatedText")
                if (translated.isBlank()) error("翻译服务没有返回结果")
                main.post { callback(Result.success(translated)) }
            } catch (e: Exception) {
                main.post { callback(Result.failure(e)) }
            }
        }
    }
}
