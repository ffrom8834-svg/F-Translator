package com.example.ftranslator

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private var speech: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFFF7F8FC.toInt())
        }
        root.addView(TextView(this).apply {
            text = "F-Translator"
            textSize = 26f
            setTextColor(0xFF17213A.toInt())
        })
        root.addView(TextView(this).apply {
            text = "四合一联网翻译 · 自动识别 → 简体中文"
            textSize = 14f
            setTextColor(0xFF65708A.toInt())
            setPadding(0, 4, 0, 18)
        })
        input = EditText(this).apply {
            hint = "输入或粘贴需要翻译的文字…"
            minLines = 3
            gravity = Gravity.TOP
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 150))
        val translate = button("翻译文字") { translate(input.text.toString()) }
        root.addView(translate, fullWidth())
        val row1 = LinearLayout(this)
        row1.addView(button("读取剪贴板") { readClipboard() }, weighted())
        row1.addView(button("语音输入") { startSpeech() }, weighted())
        root.addView(row1)
        root.addView(button("开启悬浮球") { enableFloating() }, fullWidth())
        root.addView(button("屏幕截图翻译（授权后）") { requestScreenCapture() }, fullWidth())
        status = TextView(this).apply {
            text = "状态：等待操作"
            textSize = 13f
            setTextColor(0xFF65708A.toInt())
            setPadding(0, 14, 0, 6)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "翻译结果"
            textSize = 16f
            setTextColor(0xFF17213A.toInt())
        })
        output = TextView(this).apply {
            text = "译文会显示在这里"
            textSize = 18f
            setTextColor(0xFF17213A.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("复制译文") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("translation", output.text))
            status.text = "状态：译文已复制"
        }, fullWidth())
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }
    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 5 }
    private fun weighted() = LinearLayout.LayoutParams(0, -2, 1f)

    private fun translate(text: String) {
        status.text = "状态：正在联网翻译…"
        Translator.translate(text) { result ->
            result.onSuccess {
                output.text = it
                status.text = "状态：翻译完成"
            }.onFailure {
                status.text = "状态：翻译失败：${it.message ?: "请检查网络"}"
            }
        }
    }

    private fun readClipboard() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val value = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (value.isBlank()) status.text = "状态：剪贴板没有文字"
        else {
            input.setText(value)
            translate(value)
        }
    }

    private fun startSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "状态：此设备没有可用的语音识别服务"
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 20)
            return
        }
        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                input.setText(spoken)
                translate(spoken)
            }
            override fun onError(error: Int) { status.text = "状态：语音识别失败（代码 $error）" }
            override fun onReadyForSpeech(params: Bundle?) { status.text = "状态：正在聆听…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "状态：正在识别…" }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "auto")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "auto")
        }
        speech?.startListening(intent)
    }

    private fun enableFloating() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        } else {
            startService(Intent(this, FloatingService::class.java))
            status.text = "状态：悬浮球已启动"
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), 30)
    }

    @Deprecated("Deprecated Android callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 30 && resultCode == RESULT_OK && data != null) {
            status.text = "状态：已授权屏幕捕获。下一版接入屏幕 OCR；当前可用截图后粘贴文字翻译。"
        }
    }

    override fun onDestroy() {
        speech?.destroy()
        super.onDestroy()
    }
}
