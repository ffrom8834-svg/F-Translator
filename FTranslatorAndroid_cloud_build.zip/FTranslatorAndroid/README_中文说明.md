# F-Translator 安卓四合一联网翻译（开发起始版）

这是一个 Android Studio 项目源码，不是已经编译好的 APK。

## 当前包含
- A 文字翻译：输入文字并调用联网翻译接口。
- B 剪贴板翻译：在应用内点击读取剪贴板；安卓会按系统版本/隐私策略限制后台读取。
- C 屏幕翻译：已加入系统屏幕捕获授权入口。当前版本尚未完成 MediaProjection 截屏帧处理与 ML Kit OCR 串接，因此不能宣称屏幕识别已经可用。
- D 语音翻译：调用 Android SpeechRecognizer 识别语音，再将识别文本送去翻译。
- 悬浮球：可申请悬浮窗权限并显示一个简易悬浮按钮。

## 联网翻译服务
当前示例使用 MyMemory 公共 API（`api.mymemory.translated.net`），有频率/用量限制、服务可用性和隐私政策风险，不适合直接作为商业产品或高频长期服务。翻译文本会发送给第三方服务。正式使用前应更换为你信任的翻译 API，并阅读其隐私条款。

## 如何构建
1. 在电脑安装 Android Studio（建议较新版本）及 Android SDK 35。
2. 解压项目并在 Android Studio 中打开 `FTranslatorAndroid` 文件夹。
3. 等待 Gradle 同步完成。
4. 连接安卓手机，允许 USB 调试。
5. 点击 Run 安装测试；或 Build > Build APK(s) 生成 APK。

## 安卓权限
- 悬浮窗：设置中允许 F-Translator 显示在其他应用上层。
- 麦克风：使用语音翻译时授权。
- 屏幕捕获：系统弹窗中手动确认。屏幕捕获不应在用户不知情时进行。

## 已知限制
这是可继续开发的 MVP 源码，不是完整成品：
- 悬浮球目前主要用于唤起应用，不是完整悬浮翻译面板。
- 屏幕捕获后的 OCR 流程尚未接通。
- 自动语言检测依赖第三方翻译 API 对 `autodetect` 的支持，可能需要替换服务或先增加语言检测步骤。
- Android 各厂商对后台服务、悬浮窗和语音识别的限制不同。
- 当前代码未包含正式发布所需的隐私政策、服务条款、崩溃监控和 API 密钥管理。

## 建议下一阶段
完成真正的可拖动悬浮窗翻译面板、MediaProjection + ML Kit OCR、译文历史记录、翻译服务配置页，以及对 Android 11（API 30）的真机测试。


## 无电脑：使用 GitHub 云端编译（已附工作流）
1. 在手机浏览器打开 https://github.com 并注册免费账号。
2. 登录后新建一个 Public 或 Private repository，名称可填 `F-Translator`。
3. 将本 ZIP 解压后，把里面所有文件和隐藏的 `.github` 文件夹上传到仓库根目录（GitHub 网页端可用 Add file / Upload files）。
4. 提交文件后，进入仓库的 Actions 页面，选择 `Build Android APK`，点击 Run workflow。
5. 构建成功后打开本次运行记录，在 Artifacts 区域下载 `F-Translator-debug-apk`，解压得到 `app-debug.apk`。
6. 将 APK 下载到手机并安装。安卓可能会要求允许浏览器安装未知应用。

提示：GitHub 的网页上传有时不方便处理隐藏文件夹 `.github`。如果手机网页端看不到该文件夹，可先切换浏览器“桌面版网站”，再上传。不要把任何个人密钥或密码放进仓库。
